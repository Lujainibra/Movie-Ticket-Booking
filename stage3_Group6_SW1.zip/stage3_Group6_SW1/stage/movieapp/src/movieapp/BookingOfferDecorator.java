
package movieapp;


/**
 *
 * @author Lujain
 */
public class BookingOfferDecorator extends BookingDecorator {
  
    public BookingOfferDecorator(BookingBuilderTemplate offers) {
        super(offers);
    }


    @Override   
    public void buildDay(){
        offers.buildDay();
    }

    @Override 
    public void buildMovie(){
        offers.buildMovie();
    }

    @Override 
    public void buildTime(){
        offers.buildTime();
    }

    @Override 
    public void buildSeat(){
        offers.buildSeat();
    }

    @Override 
    public void buildCost(){
        offers.buildCost();
    }

    @Override 
    public void buildTicket(){
        //offers.buildTicket();
        setPopcornOffer(offers);
    }
    
    
    private void setPopcornOffer(BookingBuilderTemplate offers)   {
        
        System.out.println("-----$$$-----$$$-----$$$----$$$----- ");
        System.out.println("     You Get Spicail Offer\n Free PobCorn for each VIP ticket ");
        System.out.println("-----$$$-----$$$-----$$$----$$$----- ");

    } 

    @Override
    public Ticket getTicket() {
        throw new UnsupportedOperationException("Not supported yet."); 
    }

   
   
}
