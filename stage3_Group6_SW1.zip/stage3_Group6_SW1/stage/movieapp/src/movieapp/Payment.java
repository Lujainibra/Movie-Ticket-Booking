package movieapp;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author Lujain
 */
public class Payment {

    private static Scanner sc = new Scanner(System.in);
    private static String continuation; // to continue
    private int paymentMethod;
    private String cardName;
    private long cardNumber;
    private int cvv;
    private static String inputNo;
    private static Pattern pattern = Pattern.compile("-?\\d+(\\.\\d+)?");

// getter and setter
    public String getContinue() {
        return continuation;
    }

    public void setContinue(String cont) {
        this.continuation = cont;
    }

    public int getPayMethod() {
        return paymentMethod;
    }

    public void setPayMethod(int payMethod) {
        this.paymentMethod = payMethod;
    }

    public String getCardName() {
        return cardName;
    }

    public void setCardName(String cardName) {
        this.cardName = cardName;
    }

    public long getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(long cardNumber) {
        this.cardNumber = cardNumber;
    }

    public int getCvv() {
        return cvv;
    }

    public void setCvv(int cvv) {
        this.cvv = cvv;
    }
    
     private static boolean cardNameValidation(String card) {
        String regex = "^[a-zA-Z\\\\s]+";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(card);
        return matcher.matches();
    }
    private static boolean cardValidation(String card) {
        String regex = "^\\d{16}$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(card);
        return matcher.matches();
    }

    private static boolean cvvValidation(String cvv) {
        String regex = "^\\d{3}$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(cvv);
        return matcher.matches();
    }

    public static void payment() {
        do {
            System.out.println("Do you want continue to payment? yes or no ");
            continuation = sc.nextLine();
            switch (continuation) {

                case "yes":
                    Payment payMethod1 = new Payment();
                    int payMethod = 0;
                    do {
                        System.out.println("Please select pay Method \n Enter 1 for credit card or 2 for cashe");

                        String temp = sc.next();

                        if (isNumber(temp)) {
                            payMethod = Integer.parseInt(temp);
                        } else {
                            System.out.println("Invalid Input, please enter NUMBER, Try Again");
                            continue;
                        }

                        if (payMethod == 1) {
                            payMethod1.setPayMethod(payMethod);
                            System.out.println("Please enter your name in the card: ");
                            String CardName = sc.next();
                            while (!cardNameValidation(CardName)) {
                                System.out.println("Invalid card name, Please Enter letters only , Try Again :");
                                CardName = sc.next();
                            }
                            payMethod1.setCardName(CardName);

                            System.out.println("Please enter number of the card: ");
                            String CardNumber = sc.next();
                            while (!cardValidation(CardNumber)) {
                                System.out.println("Invalid card number, Please Enter 16 numbers, Try Again :");
                                CardNumber = sc.next();
                            }
                            payMethod1.setCardNumber(Long.parseLong(CardNumber));

                            System.out.println("Please enter CVV of the card: ");
                            String cvv = sc.next();
                            while (!cvvValidation(cvv)) {
                                System.out.println("Invalid CVV, Please Enter 3 numbers, Try again :");
                                cvv = sc.next();
                            }
                            payMethod1.setCvv(Integer.parseInt(cvv));

                            System.out.println("  Successfully payment !!");
                        } else if (payMethod == 2) {
                            payMethod1.setPayMethod(payMethod);
                            System.out.println("Booking is done \n please pay within 42 hours so that the booking is not cancelled");
                        } else {
                            System.out.println("Wrong Input, please enter NUMBER, Try again");
                        }
                    } while (payMethod != 1 && payMethod != 2);

                    
                    break;

                case "no":
                    System.out.println("Do you want back to Day list or logout?\n Enter (b) for back to Booking Page \n Enter (c) for logout");
                    inputNo = sc.next();

                    do {
                        if (B_InputNo()) {
                            
                            Main.getBookingType();
                            
                        } else if (C_InputNo()) { // for log out
                            System.out.println("logout is done ...we are wating for you next time ");
                        } else {
                            System.out.println("Wrong input! please enter (b) or (c), Try Again");
                        }
                    } while (!B_InputNo() && !C_InputNo());

                    break;

                default:
                    System.out.println("Wrong Input! please enter (yes) or (no), Try Again");
            }
        } while (!continuation.equals("yes") && !continuation.equals("no"));

    }

    public static boolean C_InputNo() {
        return inputNo.equals("c") || inputNo.equals("C");
    }

    public static boolean B_InputNo() {
        return inputNo.equals("b") || inputNo.equals("B");
    }

    private static boolean isNumber(String n) {
        if (n == null) {
            return false;
        }
        return pattern.matcher(n).matches();
    }
}
