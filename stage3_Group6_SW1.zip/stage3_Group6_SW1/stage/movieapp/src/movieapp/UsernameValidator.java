
package movieapp;

/**
 *
 * @author Lujain
 */
public class UsernameValidator extends RegisterProcessChain {

    public UsernameValidator(int level) {
        this.level = level;
    }


    @Override
    protected boolean validate(String username) {
        if (username.length() < 8 || isUserNameExist(username)) {
            return false;
        }
        return true;
    }

    private boolean isUserNameExist(String username) {
        //check every user
        for(Accaunt u: Users.users) {
            if(u.getUsername().equals(username)) {
                return true;
            }
        }
        return false;
    }
    
 
    
}
