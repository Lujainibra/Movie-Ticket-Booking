
package movieapp;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author Lujain
 */
public class EmailValidator extends RegisterProcessChain {

    public EmailValidator(int level) {
        this.level = level;
    }


    @Override
    protected boolean validate(String email) {
        String regex = "^[_a-zA-Z0-9-\\+]+(\\[._a-zA-Z0-9-]+)*@[a-zA-Z0-9-]+(\\.[a-zA-Z0-9]+)$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }

    
   
}