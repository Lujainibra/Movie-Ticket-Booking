
package movieapp;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author Lujain
 */
public class MobileValidator extends RegisterProcessChain {

    public MobileValidator(int level) {
        this.level = level;
    }


    @Override
    protected boolean validate(String mobile) {
        String regex = "^05\\d{8}$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(mobile);
        return matcher.matches();
    }

    
    
}
