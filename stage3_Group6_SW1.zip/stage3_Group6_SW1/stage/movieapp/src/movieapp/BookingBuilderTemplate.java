package movieapp;



/**
 *
 * @author Lujain
 */
public abstract class BookingBuilderTemplate {
    

    public abstract void buildDay();
    
    public abstract void buildMovie();
    
    public abstract void buildTime();
    
    public abstract void buildSeat();
    
    public abstract void buildCost();
    
    public abstract void buildTicket();
    
    public abstract Ticket getTicket();
    

    public final void makeBooking() {

        buildDay();
    
        buildMovie();
    
        buildTime();
    
        buildSeat();
    
        buildCost();
    
        buildTicket();

    }
  
    
    
}
