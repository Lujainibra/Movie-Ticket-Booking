package movieapp;
import java.util.Scanner;
import java.util.regex.Pattern;

/**
 *
 * @author Lujain
 */
public class Ticket {
    
     Scanner sc = new Scanner(System.in);
     int numberOfMovie = -1;
     String selectedMovie;
     int seat = -1;
     String selectedSeat;
     int inputedSeat = -1;
     String[] seatPlace = {"<1> Front seats ", "<2> Back seats ", "<3> Side seats ", "<4> Middle seats"};
     int inputedTime = -1;
     String selectedTime;
     int inputedDay = -1;
     String selectedDay;
     private Pattern pattern = Pattern.compile("-?\\d+(\\.\\d+)?");

  
    public void getDay() {

        System.out.println("List of days available this month: ");
        for (int i = 0; i < Movie.getDay().length; i++) {
            System.out.println(Movie.getDay()[i]);
        }

        do {
            System.out.println("Please enter number of fit date from list here :");
            String temp = sc.next();
            if (isNumber(temp)) {
                inputedDay = Integer.parseInt(temp);
            } else {
                System.out.println("Invalid Input, please enter NUMBER, Try Again");
                continue;
            }

            if (inputedDay < 0 || inputedDay > Movie.getDay().length) {
                System.out.println("Invalid day!!, please enter an available number from the list");
            }
        } while (inputedDay < 0 || inputedDay > Movie.getDay().length);

        selectedDay = Movie.getDay()[inputedDay - 1].substring(3, 11);
        
    }

    public void getTime() {

        System.out.println("List of Time available: ");
        for (int i = 0; i < Movie.getTime().length; i++) {
            System.out.println(Movie.getTime()[i]);
        }

        do {
            System.out.println("Please enter time here: ");

            String temp = sc.next();
            if (isNumber(temp)) {
                inputedTime = Integer.parseInt(temp);
            } else {
                System.out.println("Invalid Input, please enter NUMBER, Try Again");
                continue;
            }

            if (inputedTime < 0 || inputedTime > Movie.getTime().length) {
                System.out.println("Invalid Time!!, please enter an available number from the list");
            }
        } while (inputedTime < 0 || inputedTime > Movie.getTime().length);

        selectedTime = Movie.getTime()[inputedTime - 1].substring(3);
        System.out.println("you selected Date " + selectedDay + " on " + selectedTime);
        System.out.println("#-#-#-#-#-#-#-#-#-#-#-#-#-#-#");
        

    }

    public void getMovie() {

        System.out.println("Movie list : ");
        for (int i = 0; i < Movie.getMovielist().length; i++) {
            System.out.println(Movie.getMovielist()[i]);
        }

        do {
            System.out.println("If you want booking enter number of Movie here or (0)to logout: ");

            String temp = sc.next();
            if (isNumber(temp)) {
                numberOfMovie = Integer.parseInt(temp);
            } else {
                System.out.println("Invalid Input, please enter NUMBER, Try Again");
                continue;
            }
            // enter 0 make logout 
            if (numberOfMovie == 0) {
                System.out.println("logout is done ...we are wating for you next time ");
            } else if (numberOfMovie > 0 && numberOfMovie <= Movie.getMovielist().length) {
                selectedMovie = Movie.getMovielist()[numberOfMovie - 1].substring(3, Movie.getMovielist()[numberOfMovie - 1].length());
                System.out.println("you select the movie " + selectedMovie);
                System.out.println("#-#-#-#-#-#-#-#-#-#-#-#-#-#-#");
                
            } else {
                System.out.println("Invalid Movie!!, please enter an available number from the list");
            }
        } while (numberOfMovie > Movie.getMovielist().length || numberOfMovie < 0);
    }

    public void getSeat() {

        do {
            System.out.println("Please Choose haw many seats would you like: ");
            String temp = sc.next();
            if (isNumber(temp)) {
                seat = Integer.parseInt(temp);
            } else {
                System.out.println("Invalid Input, please enter NUMBER, Try Again");
                continue;
            }
            if (seat < 0) {
                System.out.println("Invalid Seats!!, please enter an available number from the list");
            }
        } while (seat < 0);

        for (int i = 0; i < seatPlace.length; i++) {
            System.out.println(seatPlace[i]);
        }
        do {
            System.out.println("Choose place of seats: ");

            String temp = sc.next();
            if (isNumber(temp)) {
                inputedSeat = Integer.parseInt(temp);
            } else {
                System.out.println("Invalid Input, please enter NUMBER, Try Again");
                continue;
            }

            if (inputedSeat < 0 || inputedSeat > seatPlace.length) {
                System.out.println("Invalid Place!!, please enter an available number from the list");
            }

        } while (inputedSeat < 0 || inputedSeat > seatPlace.length);

        selectedSeat = seatPlace[inputedSeat - 1].substring(4);
        System.out.println("You have selected " + seat + " " +selectedSeat + " seat(s) for the movie");
        System.out.println("#-#-#-#-#-#-#-#-#-#-#-#-#-#-#");
        
    }
    


    private boolean isNumber(String n) {
        if (n == null) {
            return false;
        }
        return pattern.matcher(n).matches();
    }
        public String getMovieSelected() {
        return selectedMovie;
    } 
        
    

}
