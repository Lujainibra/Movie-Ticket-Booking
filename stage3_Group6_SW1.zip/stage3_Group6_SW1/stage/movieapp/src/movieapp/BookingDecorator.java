
package movieapp;

/**
 *
 * @author Lujain
 */
/**
 *
 * @author Lujain
 */
public abstract class BookingDecorator extends BookingBuilderTemplate {
    
    protected BookingBuilderTemplate offers;
    
    public BookingDecorator(BookingBuilderTemplate offers){ 
        this.offers=offers;
    }


    @Override 
    public void buildDay(){
        offers.buildDay();
    }

    @Override 
    public void buildMovie(){
        offers.buildMovie();
    }

    @Override 
    public void buildTime(){
        offers.buildTime();
    }

    @Override 
    public void buildSeat(){
        offers.buildSeat();
    }

    @Override 
    public void buildCost(){
        offers.buildCost();
    }

    @Override 
    public void buildTicket(){
        offers.buildTicket();
    }



}
