package movieapp;

 
import java.util.Scanner;
import java.util.regex.Pattern;

public class Main {

     static int choice; 
     static Users users = new Users();
     static Scanner sc = new Scanner(System.in);
     static private  Pattern pattern = Pattern.compile("-?\\d+(\\.\\d+)?");
     static int bookingType = -1;
     static BookingBuilderTemplate book1 = new VIP();
     static BookingBuilderTemplate book2 = new Classic();
     static BookingBuilderTemplate popcorn = new BookingOfferDecorator(book1);
    
    
    public static  void getBookingType() {

        System.out.println("Please Choose Ticket Type from List: ");
        do {
            System.out.println("To Booking VIP ticket enter (1) \nTo Booking Classic ticket enter (2) \n ");
            String temp = sc.next();
            if (isNumber(temp)) {
                bookingType = Integer.parseInt(temp);
            } else {
                System.out.println("Invalid Input, Try Again");
                continue;
            }

            if (bookingType == 1) {

                book1.makeBooking();
                book1.getTicket();
                popcorn.buildTicket();
             

            } else if (bookingType == 2) {

                book2.makeBooking();
                book2.getTicket();
                
            } else {
                System.out.println("Invalid Type!!!");
            }
        } while (bookingType < 0 || bookingType > 2);

    }

    private static boolean isNumber(String n) {
        if (n == null) {
            return false;
        }
        return pattern.matcher(n).matches();
    }

 
    public static void main(String[] args) {

        do {
            System.out.println("\n#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#");
            System.out.println("---- WELCOM TO FOX CINEMA ---- ");
            System.out.println("#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#");
            System.out.println(" TO REGISTER ENTER (1)");
            System.out.println(" TO LOGIN ENTER (2)");
            System.out.println(" TO EXIT (3)\n");
            System.out.print("Enter your choice: ");

            String temp = sc.next();
            
            if(pattern.matcher(temp).matches()){
                choice = Integer.parseInt(temp);
            }else{
                System.out.println("Invalid option, Try again!!");
                continue;
            }
            

            switch (choice) {
                case 1:
                    users.register();
                    getBookingType();
                    break;
                case 2:
                    if (users.login()) {
                    getBookingType();
                    }
                    break;
                case 3:
                    break;
                default:
                    System.out.println("Invalid option, Try again!!");
            }

        } while (choice != 3);
    }
}

    

