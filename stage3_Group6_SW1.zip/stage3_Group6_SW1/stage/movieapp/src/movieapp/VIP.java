package movieapp;



/**
 *
 * @author Lujain
 */
public class VIP extends BookingBuilderTemplate {

    private Ticket ticket;
    private int cost;

    public VIP() {
        this.ticket= new Ticket();
    }
    
      
    @Override
    public void buildDay() {
        ticket.getDay(); 
    }
        
    @Override
    public void buildMovie(){
        ticket.getMovie();
    }
        
    @Override
    public void buildTime() {
        ticket.getTime();
    } 
     
    @Override
    public void buildSeat(){
        ticket.getSeat();
    }
     
    @Override
    public void buildCost(){
     
        cost = 60*ticket.seat;
        System.out.println(" The cost is " + cost +" SR");  
        Payment.payment();
    }
    
    
    @Override
    public void buildTicket(){
        
        System.out.println("-----------------------------------");
        System.out.println("------- Thank you for booking -------\n ##   Booking Detailes  ##");
        System.out.println("Ticket Type : VIP");
        System.out.println("Movie Name: " + ticket.getMovieSelected());
        System.out.println("Number of seats: " + ticket.inputedSeat);
        System.out.println("Place of seats: " + ticket.selectedSeat);
        System.out.println("Day and Time: " + ticket.selectedDay + ticket.selectedTime);
        System.out.println("The Cost is: " +cost);
        System.out.println("-----------------------------------");
        
    }
    
    @Override
    public Ticket getTicket(){
        return this.ticket;
    }
     
    

}
