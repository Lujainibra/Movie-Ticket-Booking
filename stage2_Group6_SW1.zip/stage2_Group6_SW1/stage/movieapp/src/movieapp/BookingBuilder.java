package movieapp;



public interface BookingBuilder {
    
    public void buildDay();
    
    public void buildMovie();
    
    public void buildTime();
    
    public void buildSeat();
    
    public void buildCost();
    
    public void buildTicket();
    
    public Ticket getTicket();
    
}
