package movieapp;
public class Movie {
  private static String[] movieList={" 1) Batman"," 2) Spyderman"," 3) Cruella"," 4) Smile"};
  private static String[] day = {"<1> 16/Oct \t monday", "<2> 17/Oct \t tuseday", "<3> 18/Oct \t wensday", "<4> 19/Oct \t thursday", "<5> 21/Oct \t saturday", "<6> 23/Oct \t tuseday" };
  private static String [] time={"<1> 23:00PM","<2> 12:00AM","<3> 2:20AM","<4> 4:30AM","<5> 9:00AM","<6> 10:40AM","<7> 13:00PM","<8> 15:20PM","<9> 17:00PM","<10> 20:00PM","<11> 22:00PM"};

   
  
  
    public static String[] getMovielist() {
        return movieList;
    }

    public static void setMovielist(String[] movielist) {
        Movie.movieList = movielist;
    }

    public static String[] getDay() {
        return day;
    }

    public static void setDay(String[] day) {
        Movie.day = day;
    }

    public static String[] getTime() {
        return time;
    }

    public static void setTime(String[] time) {
        Movie.time = time;
    }
    
}

