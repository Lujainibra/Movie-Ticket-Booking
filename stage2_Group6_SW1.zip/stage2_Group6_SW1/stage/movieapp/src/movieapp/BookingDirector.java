package movieapp;
public class BookingDirector {
    
    private BookingBuilder builder;
    
    public BookingDirector(BookingBuilder builder){
        this.builder = builder;
    }
    
 public Ticket getTicket(){
  
     return this.builder.getTicket();
 }
 
 
 public void makeBooking(){
 
    this.builder.buildDay();
    
    this.builder.buildMovie();
    
    this.builder.buildTime();
    
    this.builder.buildSeat();
    
    this.builder.buildCost();
    
    this.builder.buildTicket();
 }
 
}   
    
    
    

