package movieapp;
public abstract class BookingDecorator implements BookingBuilder{
    
    protected BookingBuilder offers;
    
    public BookingDecorator(BookingBuilder offers){
        
     this.offers=offers;
    }
    @Override 
    public void buildDay(){
    
    offers.buildDay();
    }
    @Override 
    public void buildMovie(){
    
    offers.buildMovie();
    }
    @Override 
    public void buildTime(){
    
    offers.buildTime();
    }
    @Override 
    public void buildSeat(){
    
    offers.buildSeat();
    }
    @Override 
    public void buildCost(){
    offers.buildCost();
    
    }
    @Override 
    public void buildTicket(){
    offers.buildTicket();
    
    
    }
}
