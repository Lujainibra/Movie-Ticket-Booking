package movieapp;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import static movieapp.Accaunt.sc;

/**
 *
 * @author Lujain
 */
public class Users { //Represents all the registered users
    
    static ArrayList<Accaunt> users = new ArrayList<>();//to store new users
    
        private boolean emailValidation(String email) {
        String regex = "^[_a-zA-Z0-9-\\+]+(\\[._a-zA-Z0-9-]+)*@[a-zA-Z0-9-]+(\\.[a-zA-Z0-9]+)$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }

    private boolean mobileValidation(String mobile) {
        String regex = "^05\\d{8}";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(mobile);
        return matcher.matches();
    }

    public void register() { // when the first time of using the program 
        
        Accaunt newAccaunt = new Accaunt();

        System.out.println("\nEnter your Name :");
        String name = sc.next();
        newAccaunt.setName(name);

        System.out.println("Enter your Email :");
        String email = sc.next();
        while (!emailValidation(email)) {
            System.out.println("Invalid Email,Please enter a valid Email (xxx@axxx.xxx):");
            email = sc.next();
        }
        newAccaunt.setEmail(email);

        System.out.println("Enter The Username:");
        String username = sc.next();
        while (username.length() < 8 || isUserNameExist(username)) {
            
            if(username.length() < 8){
                System.out.println("Username should have more than 8 characters,  Please Enter Again :");
            }else{
                System.out.println("This username is already used,  Please Enter a New username :");
            }
            username = sc.next();
        }

        newAccaunt.setUsername(username);

        System.out.println("Enter The password :");
        String password = sc.next();
        while (password.length() < 8) {
            System.out.println("Password should have more than 8 characters,  Please Enter Again :");
            password = sc.next();
        }
        newAccaunt.setPassword(password);

        System.out.println("Enter your Phone :");
        String phone = sc.next();
        while (!mobileValidation(phone)) {
            System.out.println("Invalid phone number,Please enter a valid phone number with 10 digits (05XXXXXXXX):");
            phone = sc.next();
        }
        newAccaunt.setPhone(Integer.parseInt(phone));

        //add to the system
        users.add(newAccaunt);
        System.out.println("Welcom " + name + ", The registeration was successful !\n");

    }

    public boolean login() {
        
        System.out.println("\nEnter The Username:");
        String username = sc.next();

        System.out.println("Enter The password :");
        String password = sc.next();

        if(isPasswordCorrect(username, password)) {
            System.out.println("Welcom back !");
            return true;
        }
        
        System.out.println("Username and Password are incorrect, Try again !"); //
        return false;//login false
    }
    
    private boolean isUserNameExist(String username) {
        //check every user
        for(Accaunt u: users) {
            if(u.getUsername().equals(username)) {
                return true;
            }
        }
        return false;
    }
    
    private boolean isPasswordCorrect(String username, String password) {
        //check every user
        for(Accaunt u: users) {
            if(u.getUsername().equals(username) && u.getPassword().equals(password)) {
                return true;
            }
        }
        
        return false;
    }
    
}
